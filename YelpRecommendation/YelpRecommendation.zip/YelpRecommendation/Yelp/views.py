from django.shortcuts import render,render_to_response
from Yelp.models import Yelp

from django.http import HttpResponse
from django.template.loader import get_template

from django.template import Context
from django.core.exceptions import *
from django.views.generic.base import TemplateView

from django import forms
from django.template import loader
from django.shortcuts import render
from django.http import HttpResponseRedirect

# Create your views here.
def RecommedMeAshutosh(request):
	name = "Ashutosh"
	html = "<html><body>Hi %s. Please enter the city you are in.</body></html>" %name
	return HttpResponse(html)

def hello_template(request):
	name = "Ashutosh"
	t = get_template('faltu.html')
	html = t.render(Context({'name':name}))
	return HttpResponse(html)

def search1(request):
    if request.method == 'POST':
        search_id = request.POST.get('textfield', None)
        try:
            user = Person.objects.get(name = search_id)
	    print("Hello %s Bro how are you",user)
	    #do something with user
	    html = t.render(Context({'name':user}))
            #html = ("<H1>%s</H1> ", user)
            #return HttpResponse(html)
	    return HttpResponseRedirect('html')

        except Person.DoesNotExist:
            return HttpResponse("Sorry!")  
    else:
        return render(request, 'form.html')

def index(request):
    return render(request, 'form.html')

def search(request):
    # if this is a POST request we need to process the form data
    if request.method == 'POST':
        # create a form instance and populate it with data from the request:
        #form1 = forms.CharField(label = 'Enter the city name', max_length=100)
	city_name = request.POST.get('textfield', None)
	print(city_name)
        # check whether it's valid:
            #process the data in form.cleaned_data as required
        t = ""
        if(city_name=="AZ"):
		    t = get_template('restraunt_location_Arizona.html')
        elif(city_name=="PA"):
		    t = get_template('restraunt_location_Pittsburg.html')
        else:	
		    t = get_template('faltu.html')

        locationGo = "/thanks/"
        return HttpResponse(t.render({'name':city_name},request))
    else:
	    return render(request, 'form.html')
            #form = forms.CharField(label = 'Enter the city name', max_length=100)
            #template = loader.get_template("faltu.html")
            #context = {'form': form}
            #return HttpResponse(template.render(context, request))

class HelloTemplate(TemplateView):
	
	template_name = "hello_class.html"

	def get_context_view(self,**kwargs):
		context = super(HelloTemplate,self).get_context_data(**kwargs)
		context['name'] = "Ashutosh"
		return context


def articles(request):
	return render_to_response('articles.html',{'articles': Yelp.objects.all()})

def article(request,article_id=1):
	return render_to_response('article.html',{'article':Yelp.objects.get(id=article_id)} )
